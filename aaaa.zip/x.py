import os
import UnityPy

root_dir = "assets/android/gameassetbundles"
for dirpath, _, filenames in os.walk(root_dir):
    for filename in filenames:
        file_path = os.path.join(dirpath, filename)
        try:
            env = UnityPy.load(file_path)
            for obj in env.objects:
                if obj.type.name == "TextAsset":
                    if "items" in obj.read().name.lower():
                        print(f"[FOUND] {obj.read().name} in {file_path}")
        except:
            pass